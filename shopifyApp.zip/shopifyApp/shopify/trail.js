//$.noConflict();
jQuery(document).ready(function(){

  var  getUrl= Shopify.shop;

	ajax_submit();
		
		
		function ajax_submit(){	
			var p_url = 'https://fortvision.com/shopify/publishid.php?shop='+getUrl;
			var value= {'baseUrl': getUrl};
			jQuery.ajax({
				type: "POST",	
				url: p_url,
				data: value, 
				success: function (data){
					//alert(data);
					$("body").prepend("<script type='application/javascript'> console.log('all ok');var element = document.createElement('script');element.setAttribute('type', 'application/javascript');element.setAttribute('src', 'https://resources.fortvision.com/staticfiles/fb-web/js/fortvision-fb-web.js'); element.setAttribute('publisher_id', '"+data+"');element.setAttribute('async', '');document.body.appendChild(element);</script>");  
				}
			}); 
		}
    });
	