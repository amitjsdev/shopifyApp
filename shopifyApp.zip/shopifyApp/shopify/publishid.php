<?php 
header('Access-Control-Allow-Origin: *'); 
 /*  echo "<pre>";
print_r($_POST);  */ 

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);
       require 'vendor/autoload.php';
	
	use Carbon\Carbon;
	use GuzzleHttp\Client;
	
	$dotenv = new Dotenv\Dotenv(__DIR__);
	$dotenv->load();
	$client = new Client();
	//$nonce =$_GET['nonce'];
	$theme_id = "";
	$access_token="";
	
	$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB')); 
	$storeName = $_GET['shop'];
	//$storeName = 'test-development-suffes.myshopify.com';
	  $select = "SELECT publisher_id FROM store_data WHERE store = '$storeName'";
	  
	   $result_order = mysqli_query($db, $select);
		$row=mysqli_fetch_assoc($result_order);
		echo  $row['publisher_id'];
	
	?>
